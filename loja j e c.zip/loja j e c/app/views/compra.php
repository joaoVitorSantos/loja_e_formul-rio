<?php

require_once "../models/Conexao.php";
require_once "../models/CrudProdutos.php";
require_once "../models/Produto.php";




$codigo = filter_input(INPUT_GET, 'codigo', FILTER_VALIDATE_INT);

$produto = $crud->buscarProduto($codigo);


print_r($produto);