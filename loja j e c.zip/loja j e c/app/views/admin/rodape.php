<br />
<!-- Footer -->
<div class="row footer">
    <footer class="py-3 bg-dark col-md-12">
        <p class="m-0 text-center text-white">Instituto Federal Catarinense de Educação, Ciência e Tecnologia</p>
    </footer>
</div>

</div>
<!-- /.container -->

<!-- Bootstrap core JavaScript -->
<script src="../../vendor/jquery/jquery.min.js"></script>
<script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>