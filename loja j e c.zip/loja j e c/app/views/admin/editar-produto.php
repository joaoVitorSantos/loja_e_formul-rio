﻿<?php
require_once __DIR__."/cabecalho.php";
require_once __DIR__ . "/../../models/CrudProdutos.php";

$crud = new CrudProdutos();

$produtos = $crud->getProdutos();

$codigo = $_GET['codigo'];

$produto = $crud->buscarProduto($codigo);




?>

<h2>Editar Produtos</h2>
<form action="../../controllers/controladorProduto.php?acao=editar" method="post">
    <div class="form-group">
        <label for="produto">Produto:</label>
        <input value="<?= $produto->nome; ?>" name="nome" type="text" class="form-control" id="produto" aria-describedby="nome produto" placeholder="">
    </div>

    <div class="form-group">
        <label for="preco">Preço:</label>
        <input value="<?= $produto->preco; ?>" name="preco" type="number" step="0.01" class="form-control" id="preco" placeholder="">
    </div>

    <div class="form-group">
        <label for="quantidade">Quantidade:</label>
        <input value="<?= $produto->quantidade; ?>" name="quantidade" type="number" class="form-control" id="quantidade" placeholder="">
    </div>

    <div class="form-group">
        <label for="Categoria">Categoria</label>
        <select name="categoria" class="form-control" id="Categoria">
            <option value = "Fruta">Fruta</option>
            <option value = "Legume">Legume</option>
            <option value = "Hortaliça">Hortaliça</option>
        </select>
    </div>

    <input name="codigo" type="hidden" value="<?= $codigo; ?>">
    <button type="submit" class="btn btn-primary" name="editar">Atualizar</button>
</form>

<?php require_once __DIR__."/rodape.php"; ?>