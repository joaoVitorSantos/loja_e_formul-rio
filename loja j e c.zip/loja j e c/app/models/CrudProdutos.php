<?php
/**
 * Created by PhpStorm.
 * User: JEFFERSON
 * Date: 16/11/2017
 * Time: 10:56
 */

require_once "Conexao.php";
require_once "Produto.php";

class CrudProdutos {

    private $conexao;
    private $produto;

    public function __construct() {
        $this->conexao = Conexao::getConexao();
    }

    public function salvar(Produto $produto){
        $sql = "INSERT INTO tb_produtos (nome, preco, categoria, quantidade_estoque) VALUES ('$produto->nome', '$produto->preco', '$produto->categoria', '$produto->quantidade')";

        $this->conexao->exec($sql);
    }

    public function buscarProduto(int $codigo){
        $consulta = $this->conexao->query("SELECT * FROM tb_produtos WHERE codigo = $codigo");
        $prod = $consulta->fetch(PDO::FETCH_ASSOC);

        return new Produto($prod['codigo'], $prod['nome'], $prod['preco'], $prod['categoria'], $prod['quantidade_estoque']);

    }

    public function getProdutos(){
        $consulta = $this->conexao->query("SELECT * FROM tb_produtos");
        $listaArray = $consulta->fetchAll(PDO::FETCH_ASSOC);

        $listaObjetos = array();

        foreach ($listaArray as $p){
            $listaObjetos[] = new Produto($p['codigo'], $p['nome'], $p['preco'], $p['categoria'], $p['quantidade_estoque']);
        }


        return $listaObjetos;
    }

    public function comprar($codigo, $quantidade) {

        $produto = $this->conexao->query("SELECT quantidade_estoque FROM tb_produtos WHERE codigo = $codigo")->fetch(PDO::FETCH_ASSOC);

        if ($quantidade > $produto['quantidade_estoque']){
            return false;
        }

        $quantidadeNova = $produto['quantidade_estoque'] - $quantidade;

        return $this->conexao->exec("UPDATE tb_produtos SET quantidade_estoque = $quantidadeNova WHERE codigo = $codigo");


    }

    public function editar($id, $nome, $preco, $categoria, $quantidade){

//        $this->conexao->exec("UPDATE tb_produtos SET nome = '$nome', preco = '$preco', categoria = '$categoria', quantidade_estoque = '$quantidade_estoque',  WHERE codigo = '$id' ");

        $this->conexao->exec("UPDATE tb_produtos SET nome = '$nome', preco = $preco, categoria = '$categoria', quantidade_estoque = $quantidade WHERE tb_produtos.codigo = $id;");

    }

    public function excluir($id){
        $this->conexao->exec("DELETE FROM tb_produtos WHERE codigo = '$id' ");
    }
}