<?php
/**
 * Created by PhpStorm.
 * User: JEFFERSON
 * Date: 09/11/2017
 * Time: 10:40
 */

require_once "Conexao.php";

class Produto
{

    public $codigo;
    public $nome;
    public $preco;
    public $categoria;
    public $quantidade = 0;

    public function __construct($codigo = null, $nome, $preco, $categoria, $quantidade)
    {
        $this->codigo = $codigo;
        $this->nome = $nome;
        $this->preco = $preco;
        $this->categoria = $categoria;
        $this->quantidade = $quantidade;
    }

    public function getDisponibilidade(){
        if($this->quantidade > 0){
            return "Disponível";
        }else {
            return "Indisponível";
        }
    }

    public function comprar(){
        


    }
}




